<?php
require_once (dirname(dirname(__FILE__)) . '/clients.class.php');
class Clients_mysql extends Clients {}