<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9054d4c5ada7631dd376b20412309e4b',
      'native_key' => 'core',
      'filename' => 'modNamespace/4d5f04a3b2b9ca168470958e582a540f.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'e7d510847c88e82d99b703250440d7ba',
      'native_key' => 1,
      'filename' => 'modWorkspace/67580825096520caa14aa46961edee24.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '5a03d2b1a3eb32316c04c86739dbb26b',
      'native_key' => 1,
      'filename' => 'modTransportProvider/6c8a93ba044b18bc36c2f6a21063cf72.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ec8ad4ebe676c4d128077e5d9d324daf',
      'native_key' => 1,
      'filename' => 'modAction/7a260864fb7460ce9d5ecf98641f001c.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6afbf9740ac67677298724cba7ffa341',
      'native_key' => 3,
      'filename' => 'modAction/ffe217a673487d7ff3c1579209f72029.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0ae5a1bd7dc577aa4c90329b29dcb70d',
      'native_key' => 5,
      'filename' => 'modAction/4deefc230c887e344478810b3c049a20.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b2a6c4f0af13880db52ea6b554e2fca2',
      'native_key' => 7,
      'filename' => 'modAction/b01d7d843b0d3c47e021ba908a09a73a.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9eed3334d90ae5e367f9b2121b97518c',
      'native_key' => 8,
      'filename' => 'modAction/e51f08889396439915c636ff3df982ea.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b107f910752e26b65a4c2445e1a72612',
      'native_key' => 9,
      'filename' => 'modAction/4790e43f7b253ad10194b600bd5ef817.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ffd1b4159e9929404bc759bc2d58fd23',
      'native_key' => 10,
      'filename' => 'modAction/3407c7043e54e8abe2d8e09d4766f410.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '07bf1311e7c3ee1de3063dca3920315d',
      'native_key' => 11,
      'filename' => 'modAction/30d85dac6deaf3ae3e934c21dbc04c5c.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '012b56e3636a8e31cda56ba82543ae2a',
      'native_key' => 12,
      'filename' => 'modAction/835dd32770c394da01de6422a969816e.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '104649428c400880ee3bebeab69427b8',
      'native_key' => 13,
      'filename' => 'modAction/c65e9d9b3e89f731aa9331a383f65777.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8f47796b4f7e7e2e108db15fa451a4b3',
      'native_key' => 20,
      'filename' => 'modAction/02f3ae0968da32beaf3338101a824f3f.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c7298d924dfaf1fc9b53ff2fca0c0dcf',
      'native_key' => 21,
      'filename' => 'modAction/a13d81ce0a455070f5ab8d65803e1cb5.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '03ee6a13d63b517a1a0aaed085c11977',
      'native_key' => 22,
      'filename' => 'modAction/4829fc881f8bc45601a9688156fe39a2.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '500c093b8a270c94c9f7147f3c498162',
      'native_key' => 25,
      'filename' => 'modAction/30f243ab1e0cc881255c19ce970125ad.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7e51d3194c0b02a8f8a2d60395fee84b',
      'native_key' => 26,
      'filename' => 'modAction/bc3184a41604d5f3f417be395dd90725.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8b4fd5e5180d6e661686604e26b8ead5',
      'native_key' => 27,
      'filename' => 'modAction/4efefbdb6508e532711b7300ab130e1d.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '378ed2db7d04644243336a0a46b3f73e',
      'native_key' => 28,
      'filename' => 'modAction/2f25ca6e95dd748669d2c5b328581bbd.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f346bc7f9cc1643b1fd5ac2287990e80',
      'native_key' => 29,
      'filename' => 'modAction/573b959abac454d54aceb14e581681c1.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '2c6cb02414ca35a4f8e6152ed17f7714',
      'native_key' => 30,
      'filename' => 'modAction/5dc12f3010e10683677420e12a287d2e.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1ff514e55512e9cee3654696fa67b878',
      'native_key' => 31,
      'filename' => 'modAction/13f227b77edc97ba6e08261befc1f21b.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e8620888f580386a50ecf6bb762f6543',
      'native_key' => 32,
      'filename' => 'modAction/a7ce35a6ef4a87ad15b2659e29bbf5fc.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3bb5a0adaba2c24d5ead7d4d93df9f5c',
      'native_key' => 33,
      'filename' => 'modAction/7ed049a9742d458d7dee8ec2bb4631de.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '08b72f38f265bb72f365392d553e28ca',
      'native_key' => 34,
      'filename' => 'modAction/cd5084f9b68f5de098ee96e682309cce.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e2ee193af2eab7ce8e1d350ce91fab5a',
      'native_key' => 35,
      'filename' => 'modAction/09b36fe22147da833998513acdec8c19.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '445b190cdfb2f248667425ce75b14ad3',
      'native_key' => 36,
      'filename' => 'modAction/ba05c45acc116e82e63830b1509b8f76.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0074e341c3f42158bfa3b3df6906f9d3',
      'native_key' => 38,
      'filename' => 'modAction/9e1329f10ffdd2b1dfc9bae886998afd.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd8e7664adcabc932c2320627c3aa1a12',
      'native_key' => 39,
      'filename' => 'modAction/d92d63cfd43893e6eb24197a28ef9780.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'db2984ec822d020f6b9f2e6581382626',
      'native_key' => 40,
      'filename' => 'modAction/0acb42fff42ef10fd1af9b1fa787b04c.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '47b0817e897ec1e9063b562d8d2bf203',
      'native_key' => 41,
      'filename' => 'modAction/2d17f74ab918eae6018079d318e4ca66.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1ec58704d8274b8529ff29c98bb63cc2',
      'native_key' => 43,
      'filename' => 'modAction/a2fcaa1557aed1495c07decbf0b3ac22.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0ef60221e47a97442362965d54cb7dfa',
      'native_key' => 46,
      'filename' => 'modAction/9865555ea44092bdc58f84b7a5816446.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c39fee5f49c6cedf25dafaa76e2de41f',
      'native_key' => 50,
      'filename' => 'modAction/42b19c09164e2512249f4a783a18efe1.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'dd0b39a838916292816531babafa0740',
      'native_key' => 54,
      'filename' => 'modAction/b8b50b2fe8a1f45494a7c172b077616a.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'fa39bb52472a393bed5d9221524bc63e',
      'native_key' => 55,
      'filename' => 'modAction/b79a9e223b07f51a5abeb8c441f97ded.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7971d7553dadfb2e540cb73b4e3d58b5',
      'native_key' => 56,
      'filename' => 'modAction/a1131bc99515ed880da369c8bf156195.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1264705d6a023c6b4ff756db6656564e',
      'native_key' => 62,
      'filename' => 'modAction/7518aa91559534b3cb6867da10ae9732.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '98a29d250bf727660423f337c00d6ece',
      'native_key' => 64,
      'filename' => 'modAction/3893419c0a38596f914609f9401dce1f.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7ff6a4ec9fa48cc53a2bbaa78beefef7',
      'native_key' => 67,
      'filename' => 'modAction/163242868b0e06c7f56074a0da4b9159.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8cdd3680cf9b247558d205bb146c49ab',
      'native_key' => 70,
      'filename' => 'modAction/10f67019a5fd3ad93886b8a6b4cb2b27.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '41d45c8a4b63ca0e68a47cdf3461c466',
      'native_key' => 71,
      'filename' => 'modAction/d6fe9f6f8a2c33b12cd00935eb79e99c.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '183a2f37ab4d866ecdb9e32168bcfe52',
      'native_key' => 75,
      'filename' => 'modAction/eb110d8792323f8cda1df69fb276d2c1.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '10b0aa966eab5eb1354a8297f92bb887',
      'native_key' => 82,
      'filename' => 'modAction/d38fbe5881bbff0690c1ed72697b0adb.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '70958abcd7dc3e853f16ea2193886765',
      'native_key' => 83,
      'filename' => 'modAction/00d2c1f841e1b5b78f30bf782bf3ed5e.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e23a84d4fa1f5777949ea7ae06064d78',
      'native_key' => 84,
      'filename' => 'modAction/225886ee8c580fe73e5430abe28bde76.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f31e82547ad2560c41a057005dc2f57b',
      'native_key' => 85,
      'filename' => 'modAction/b4a85a1a1d82194de2164288dbce8f0c.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a6653645389d3e32dc3a445393d88cc3',
      'native_key' => 101,
      'filename' => 'modAction/499cd0e7ac39ae5d80c6ff91a142974c.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'bc819c7d04ef37620612ab1a70a62ad4',
      'native_key' => 102,
      'filename' => 'modAction/f0e7e83acdeab1cdfacac71f5f10cbf3.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6b48bab1b2edc544147adc6238c649a3',
      'native_key' => 103,
      'filename' => 'modAction/337350bd28de6953592740d6e23e3174.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '851f4976dc01f71059f28574330f76fa',
      'native_key' => 104,
      'filename' => 'modAction/ee5554a0e95863608510fdca4a1e0c87.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '86b23d8336041b8b364b8f31fd69c094',
      'native_key' => 105,
      'filename' => 'modAction/290e51154622a84d999869c854c5bdf8.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6332dd7f63a2a49a39e86b2cec5ee872',
      'native_key' => 106,
      'filename' => 'modAction/33cdd27c61ce69a5327b17d3052a555c.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3a3717f039d38cef79280d44565cde9d',
      'native_key' => 107,
      'filename' => 'modAction/bae7b7efe6733b7b15b2e5e9e9b8bb97.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '029df6790618f8a8fb277ab19786184d',
      'native_key' => 'dashboard',
      'filename' => 'modMenu/103f8fb9e2754529edbab76430bb4754.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '26188954c74e503ec3cc00fce5644119',
      'native_key' => 'site',
      'filename' => 'modMenu/b242a8a6e1154d9e31cc01ddf393ab55.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7e82574dee9954349b90a8c242fdc7c4',
      'native_key' => 'components',
      'filename' => 'modMenu/676eaee5dbdcbc9730bc9a0126860055.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd72105c78ded06f9aedd5b9699753303',
      'native_key' => 'security',
      'filename' => 'modMenu/be0dd08dd6f285659a72901b681e7514.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b49cc1370bed4c6ab69be407f89c9425',
      'native_key' => 'tools',
      'filename' => 'modMenu/b7d86b0a9d17bf38c6ab36e5f13d8327.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0198d810747ac53bba6bddc70cd518f3',
      'native_key' => 'reports',
      'filename' => 'modMenu/dcb6dbed595058719b6754d65101913b.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c38677ceee6276d4ba33639dd059c7d7',
      'native_key' => 'system',
      'filename' => 'modMenu/1976a8c3885af320fb00c5393363889c.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '77478bb4e1f060b7b42461e9051b6ce4',
      'native_key' => 'user',
      'filename' => 'modMenu/4f859e3e4bcb4d3f1d163beeb33837e2.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'caf40ac5bd22bf80cb06a514c8c7ad46',
      'native_key' => 'support',
      'filename' => 'modMenu/4c35bdccaace51077afdc7754055ac94.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e84eaed283652830d6c8cd7e2600f073',
      'native_key' => 1,
      'filename' => 'modContentType/b421f43564ffb54c780b4f34c919b767.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b3544af7b85dc83e14b776b301a5fe5a',
      'native_key' => 2,
      'filename' => 'modContentType/290cc62b06d65ad0d06fc85d3709faec.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '74453a09c6156cbcb4a761f3cbcd5d38',
      'native_key' => 3,
      'filename' => 'modContentType/c62dc268ff216a24e62530391f5c4349.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '17f1c21502a0691ff1bfbe59f824453b',
      'native_key' => 4,
      'filename' => 'modContentType/1b0a113ca46902fe94b8c7e948770cb4.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fe6db02b751a52aa1997e593dce88af3',
      'native_key' => 5,
      'filename' => 'modContentType/05b4605d8bf1d2048f7e4a7fc1324e58.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a88dbbaf03b1e9fc2125feed70b87e5d',
      'native_key' => 6,
      'filename' => 'modContentType/15b4195952aa25c828366d13f6689937.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1d35fe6aaf1774a792913419a375a4e2',
      'native_key' => 7,
      'filename' => 'modContentType/8af21f7f85e691226c9eab02c3383cc8.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '79a6a360f64a6334bd184f84ff776a4a',
      'native_key' => NULL,
      'filename' => 'modClassMap/0b89951d57422f405193af6e43a1d42e.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8a8bb450d73a416b45dfbcaa0a5071df',
      'native_key' => NULL,
      'filename' => 'modClassMap/2966b6497a0b5b41955bd5274ee65021.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e883f08c0772a148fac0ef0736a7d50c',
      'native_key' => NULL,
      'filename' => 'modClassMap/3e0d4d4249f309cdd34d2ee48339bffa.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c811ea29f1316225508d4a2869905ddb',
      'native_key' => NULL,
      'filename' => 'modClassMap/93ec1a411fd3e0e149e0ccd47f50a01e.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a01b3dd159305fee4d96f08eda676b0c',
      'native_key' => NULL,
      'filename' => 'modClassMap/a039c8a890dfe10b582b1e71f0ae52d8.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '88695386cce4d02bbf96b5b026e2f5d8',
      'native_key' => NULL,
      'filename' => 'modClassMap/3157744652d78f7a0edb1345ae026071.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b35663cd9e9653af9d2c3f1a04f074b0',
      'native_key' => NULL,
      'filename' => 'modClassMap/27ce768e6547d9958793f7e041994677.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '195483a0a0908b62304796e9b148d2ef',
      'native_key' => NULL,
      'filename' => 'modClassMap/00fdd0f2c38ec7b12f69c1b3a51cf545.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '86b74b932396bc247f2423d363c64539',
      'native_key' => NULL,
      'filename' => 'modClassMap/d4f9991a7120fca46f110225ad9df8f5.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9068709efb55d724bff17adbf6b213e5',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/56c60fa18974d4a9f86cb9eae7335c21.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c1cb9f02649ce6d9a663cce76cded08',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/2abf78de90f7bd91a09074a0963dda62.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e43c7fe0b1ab59b001d843f3594fcb5',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/c80512bd4052602ac19dbd237072482a.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a58b37f4a0b3a0a039d01324841407ca',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/8ba49c0ae992579060973799cc0335f7.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '114999161f27fffb09b2725850775809',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/ff1bd9187a6a8a7e7c6e64dcb4a61f82.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f0b317d94643e0bd0a65953d2181e81',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/c627635056aed7e42f99a06a306c3098.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56c30ea0b4a01512a8ff5785ada839ec',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/46baecc5a15f1f33218c369fb1afbfc8.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d3cfaec5f84c71070f90a72c680ca80',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/62d4b4ad9c988b9493113dc5df860361.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60505c443c3db4f320bb2d5a8d4f0c31',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/e3711dd072a0f8baf0d789d0849d2b9e.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '150f2211d1695f751ea6ed7eee584e51',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/e035d6ac8be9cb123150e1684478853f.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '537eae99bb3974a5bd3bde656f9091d3',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/9a53e4c25d28a71ebd35617b15a5fd37.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cae5ce13add0bf212376b910d94bff81',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/fa28d0bd09d1267a3d9efb5a0bb16c5c.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e97ab97dae6b25e193e0e9c9d3b6c606',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/c890dbdf1bb6d3d6f9fbf8fb58d5b055.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '484e7d15e280d3066e59e2e6c97c8e17',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/f27170acf7f87895707d52d40652c89c.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b68d0e6d79e1f607e2db89e369b85ed',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/16d6bf4a214b30eab248dc50b5c213bb.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb3233585d1e2b03292d4ff84e5d0334',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/3052aa4e304c2735c53c0f12a983fc4b.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13553f4e0dfc076a7c947dd9f8755e79',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/ffa013429c26f05725392a6a095e9a27.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '356b320d984478a3c311d8bd2ee284eb',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/1e1764427cca9979830f3ef129dce9c6.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4db860e67aa136f64cf4309f8a1f4bcc',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/b2c86580725a7ba9c98026f9763abf70.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20101929caf341d0c6bc73f3ae408535',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/25fcc7689c9e95686211f8fff3a4ce13.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c852c2ce5003aa6924067ee63c08c04f',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/da20c514eb020829857b3768001270dc.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bbbb965d798bcb4f4dcdd5e028a14fd',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/a37566211b86bc93f737abb7f7519db1.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2baa3377c33c45035278bc71d99437d',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/eba2eead61a0c4ace28446d32e3aaf9a.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2f8648b06b68c606bc182ef86269cf8',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/f8d3dc60c8daa08c3e5720066a9ccfe6.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d95b2121807c4f0c804b35152628ed6',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/69f691aa1a0912cc6245dbf8832ba63c.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bc3f62b18c13b7c7b6382861e7f0272',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/79f0d4d946888e97ca54d27f99e0c775.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e456e998e629943dd87f28d334ae83d',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/e8b21b37ae43964980452134977e40b9.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f4eb91f2a8022b3d8f7f569e21be9b3',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/476d214f217619ecc58b04e29a5c6f02.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76b99915fe9471b12eea015cef806b66',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/c3073eafe572a60059543d7c02f91f18.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '932489e02d3a399ac49be17c0f7e8779',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/b855a5099986d696d82c8d244278811d.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfd563e0b9ce9660c69007d797a01d03',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/7510bc0b59d570c27b302e01cf1dd079.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38637e7c01c2b5a61f572f792b077f95',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/630b5380a2288e35d5f86e7c65fa55a8.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '671e13c45c24af140adb82c4756725b1',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/82ae57e688dbd34065716d90da6f3fd1.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ac7bcd6086b93d80508191701453327',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/d0022e56d2e3b04f11ed9b056b38c745.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfe897be71888dd40898a84816c7b0ef',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/99a32e6453666fd7b2f950ca7e4a27a7.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3476c7f3e81949fa020f32eaf93fa29e',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/23d6aa7534d7e0ac99543ac13c6c50e6.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c558f77564a03395893f9bfcacbe786',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/c9f36aada4f95f9d1e54b363e91ddb2d.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '179751529627cc1466107825429f74da',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/a5c510985b3e0a8b6f6d27104ea0756a.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51f692fa42e4c78b40803851bf4f46e8',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/b89206cb39a7dd6f4102b78ff948877f.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14ef8b76da0e24e4f557883036131f1c',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/5eff8ba5b0c884ef0bb64c278c0ea62e.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eda9f15f14fc3279c5c3205dfc1b71a1',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/1b6402a3b4c37029835b359e13198a1a.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc767b02799ec70492b02c1b2d38656d',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/99e7bf0793f1997f8880fff463d711bf.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed5673d32b0589910b8bd43aa5a486c3',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/6036bd92ca2a9803cd31e4d085ddb65e.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8575825d921f45369f1f5c51ffd8d2b',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/aa1eeffe26371cae905ada55f36af0ca.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f3708f1fd4256c2392e752a0870bd95',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/970562bbbf83822d441fc6750c9374c9.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac275a7ba982975d4c0cf5b59a4326cd',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/4d81bb4b36ee8d84804ba3349bd3cd89.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8407a2d2caae5f8d9bcb9d59c51900c',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/561e4a55deb724330a9027b82d4900aa.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e86247404218ed4ec0e7429b95384642',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/83d2d87130cc1a83058d50fb04bf73ef.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b37a5412a13f61d6d40c1e7eb1c8d2b7',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6b68497fa2d1ca3e37dffb1aa27ae030.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc04c0170f5155386a67cc56b3be3c30',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/58a319abb11c06daf16aec75345a8b92.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d1d32a784c659ee122300292f3c734d',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/96581f63ad271d59781e76bf015c690a.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd226d8df8ea83bc11e56d5bcdd226712',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/7a71c2cd8c1d1414dee0af281d3c419e.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53c2a0d1f6c1f47c8287859de79d9418',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/2cdcaf6ad6212fb5766e739e863c7b61.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f341c4b06e11aeb71b45cddafd299624',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/ed22170f63f493c96fb23c8faf251025.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db355a72d2887e95cba2bb1c64a2c5cb',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/f341fdc8f0e957919b7dbe632615212a.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4370f753da8131bbe80161fa5ee3d4d',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/0f7e347f7a744d41107649348cb73d41.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f7c03686c5db07ef10c74a87190d357',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/df1d0040df021ed1ee80a4c6dd73e9a3.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '971abadd337b0302f30eeaaa860e29de',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/2458fb457b1361df25674d70d63b67f2.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '483655d73e83850a6e729ca6444ac2d7',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/aac50b20303f51c8668c049d945e36fc.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c1e54fed3df453489b7a8c3244965dc',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/bd822b56c82385656193defcc66bdb4c.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63648b5b4bf22fc50629f3b191a1e02f',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/65418ed14b41d606b185a3422d7f8258.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02b5bcca76232189e9e73d72297c394e',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/cca2698703097e5298ac82614412da3d.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '207be381938715b6d95bad46a51fe55c',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/b8ba797cff06dc1da9594037ffed3a93.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e504196119f26740a194a23e135a5ab3',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/c4fd2a5aea0cfcebb12dcfeb9c8eef75.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3301f324c2ca27c078fb502512241bae',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/a30d150d6bd6f25b08278c3df2d6e872.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd9342a85af11cf81a5d6fcaa55f9e80',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/21391c063d05e646e9d1dce8c6606a81.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb10c6d7583eaf6e7a0af337b5588b10',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/01d15386c604104e11eabaf2a7f3fa6d.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '481b997aa3fe6a025eeadba5dfc075ec',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/cd1ad82ae2c4d4cf7faedc0764889b8d.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f6aa43d7e99e9ee232319804df8455d',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/5feafcf73fef95a8036eb178c8a25767.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd21fd7b91441f9563ffd2676e3b84dc5',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/b255b407a274437e997d8d906e0c9953.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1e037a2ac2c5b5cf100bfe826469967',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/2653eec452cb0c0e42b02cfaac7c3c4c.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e45925283e4d58fafe6a6bdb3f12227',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/0b475d698e05a63de8a346b678b2fae1.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfe0572cf7dab1212cd8f397e507e335',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/a71adba79ecb5f409e2835b586faa65d.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c86a2c5830bb10c2b70fd0254bcaa37',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/e234177cebd437dc0ef0afca19914833.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db03397d84882ae2a871ade57e1f2bc8',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/7573746cc4d97e7bf8e247dc16c6e43b.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a123547b5ec033b8c6f01607c0e74c61',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/67517713c5c4b3a54370973cee2cf9fe.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04fab657945402a71352119345765386',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/e06ab09514cd48c7295ceeb277975b3e.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bbb15962fdbb19b65b8b6ecd2d865b9',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/0c98285dda61da66dc704fba02344dff.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e797b4fab5c72847c62cd9fa347a1b76',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/6806e6202e9f986b1fa74470f49ee2a5.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b278bde838ad388eeb48fd5efd807a49',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/b0a2ef840c45bbb38e5a03c6f8f96392.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d3941854734611e683ad624c93f1c94',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/bf4fb3c59dd7d5c7b65c18f66779810f.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '089d27e8d7ee6067f938495f813bff50',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/2302f8a37f30a3c6f5b115762560b19c.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89db77c8ddf32f8fd3baab95fb612e9e',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/e14b439c0717df037ba7369b586886c2.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '253b699aac53946a2d5b7f1a6615a93b',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/82ed051255abea6c150a4ca0b5c8ef78.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b361d0a59776c407d49649b2e6ed120',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/efaaa1c471b5ab841dd80f98c0d9aa51.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b94113d2e875513634377d96d8bbc90',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/d30230b449353353a0b5df033f98e2e7.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '732bd776ef9d6f8943dfe27afacd5c66',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/ff7a2880b38581552f6e4179f8d47e6e.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed7bd6ebc3e63dff65d0aaf4c8bfb9de',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/1f74c349dd9ce93bd1f0e003e687180c.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78e6c3f6378642af83b2dc1e99c447c3',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/2b2256cb531db5dae8084c943fb204b3.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9158aa86dc22db2c0b59a15606bd510',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/69f0be4198ef035a429bead01fd5f693.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e81ff39b8e49a869202a518e4214a186',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/09d3597892a727c831f00ec3dc94e621.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b743011da9df120a053f8330f7fa7c14',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/c4bb17a8413451419f44d3a2983e3858.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e29ca31ece707419ddd80f0c06fda55',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/e9b19195d0637673a2bc97b0812f1e0d.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2879d859a956c0ca67fd6d53955ed819',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/400c3ddaff6884946eda66436a3b123b.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cdc78eb624d45f18beede8976ef58b0',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/d8ff363a51c82d7df1c8c35cb6ac1a09.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07842fe637cfbcddb4bd0d3596823376',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/13dab7eddabd923dd1a86c70f888f58f.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '239c65a526c1d180c7d276c5f42d4436',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/21e5a7659c6a1291dbedd7e2baab39ff.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0f9e49f64eae684113a73ad81eddfb6',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/8d430ffaa3783106f555f10bf29fec94.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e0f60659a9c089330e3fbbfe7274cff',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/39dd475fad24c04ad4bb00c66154135e.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2770056de1e56c092cade29c7fbbd6fa',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/ca5fb3b1cfe0576fe118fa92b1e15895.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3b9e3bbbc502a38e44a65493b2c415b',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/a84304e228c2bbe3c7d4c4da9e7f10bf.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b0b3dccf31370f0cee64669bb044df4',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/820a902241c5c69d7a460dd64034cf78.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efa24d4add1800a998593db36d19cc6c',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/cb32feb3d250d085723cd538ca262953.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a567343ed1f554df26d5d637e05397a',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/9d8661dbcf85bc407767554ad850dc31.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eeaf5347807468020580df20785360c4',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/b2a0d07898d1e941b8ee7adc7484bf13.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf9b6839a33d6acd35a648a40b46df96',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/fd2b0d1746701309727fafd4b1023c12.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32ff498ec1d4d8f0d0d34be606b0725f',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/af2229c963249f011f416d29b7df0e40.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a1c261f004b95b5c52220de16031be2',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/3802f4555e9f3d4db364e1101778eac8.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c4da969f57f85e8d6421ef8d634d56c',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/42c365c5cc5ca8dd9b451984150ea477.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '675cb06e1ade69a05ca70abc0935a07c',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/95d987b31ae39c93cd69aa9f2133bb44.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cabe1ea47ec9b1e0f353027a4b3e5c18',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/00e2f3c658fc70c19c0ccc89a36fd28b.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5eac56743f9aa25894100abb3f3cd492',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/fb7627ea207b8b8675d0c0bba1a180f8.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '496af67a35c23f2340450d73c56d6ebd',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/42189edb39217a9a0ce668bfbd84ac61.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f28c1fa109599b5541e9ade410d56cf',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/66f57a92242c035775c4cf3addab01bd.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c2634ae683961d359ca6c3b06e47f70',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/f152cbe10b0c6cd9ea57ed26147571ee.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64eb319647cde0733d936e39fe62ab33',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/b8cda03dca76291688b6b724b425474e.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de8fcb671790096fe1113ffe471f1c17',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/5e96c8ec81fe0e600696839131545d3e.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20b3345298fca73e0e601851eb0cbaea',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/6f4d93cc1cfb5123949c06368d37e770.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a44769cddf6e7f1a194ad65695bdd21',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/55b5f06ecee433fb1c39abd78df6bd8f.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22e6bdc3d05da4a74cf6a7dc7dc0bc99',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/315abe6e3a51a91e23e1215d02d24cf2.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0b92c085d6413be00108c533f5bc1fe',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/9c67661370a1c9aef5a365b3d5eb66cd.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ab7b08e886615662329eeb56e687f6f',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/d75e5561400b756ef06d3b91ea5bf328.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aef9c69aa8d1a8e2c0807f3afaa7d3ae',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/82da657a97e2da2f46b16de00b8fb12e.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e1dc6ffac964761e0b5d50cde0e6366',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/f4d3b29810d524030863abcfa2ea9873.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa18ef1c698d8ba1d682eb672420c675',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/6956f8be3d73d9e9de8ed45a7670e10e.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3ca042d0e5fa4b185ec9ba8e955516f',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/d99bbc3e3a7332556e0198eb5cd3c1d7.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ec2b7f274ba8e5f42b3dff68a810117',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/f399633b25954edec1851276f29261c5.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f65b0745b3f1ce11b8c7732d091b392d',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/ea7d11d3947edd78f4dc30100484910f.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41125498228ab59335419fc25a7cd504',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/62fbeeeedeabb8f2a1844305191dfd1f.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1966b94d3ca33e69fc13e5e2beb9de1c',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/3d02963a8df5af4f6569e93390adb781.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73b7948e817012f142d7a0334fecc60a',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/f3d8d89fe18410ddaaf788fb28382514.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77074fd80ab7b4fb09f64f207139f8c7',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/55b013bad340e96bf1896422c9d07881.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d3fa2bf9aaf2a04d8891efea52f8997',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/3f58a7c19faa107bd890981d31576790.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d19876af5f11d8911cbbbc07407d59d',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/5008a767cae3ba58526889781d8e34b5.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06cd2bd4adbea29fa163504ae3f9a093',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/a4c019323a2e252b2d4c0a7e166d7b5c.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c29c7d8c5fa0f39e7d2f160a848b93a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/3d3a974c8425623898475e6c24a8319a.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0abe55971239a50633123628aed395c1',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d24c301706fbeebe9a67285706a8ca4f.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd907ea9d50720f9ae13ac5a93285b82e',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/96082d3b135bd219731bbd285816240f.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '824e1aed46e8a2a9633cd81819208c37',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/dd8c14973f34a523bf071cdc32f5d369.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1eddc5c1265dc1e86e3ecaa268bacde',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/a4896cd2fdb1996a99d3919161322017.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39c6cbccf7c1b02f0ea89463f697b7f8',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/8a7cc50dc84c0da6a37ae870ab3abecb.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93e284494ac310fe21309bfb145fe580',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/9c046eaab701c2d33de4eb257d1347c6.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2299ff239136d8671b3974a21610bdf1',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/ef39108a9d9325d2962a77188c6f0a52.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d061bf6f1db15e4e0be0fbbf8253378',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/89a6f600e98f02dee5c5412a5fe03730.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b6305cac2fb13ed8d47db5f7dd4aeda',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/697a7ab049fea7aa29fdea72987b01ea.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '459440893462786487976e1cdad0496b',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/154b79d28f9f985ad33f3c395c8ec99f.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96baa7a3d6a8efaf1ed0e2a33e61d913',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/f1ba527dd81262b8aa87d6bb30d63644.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33a40a1e92e74c97e44ca4a4752ed63c',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/9110483a0bd6d37285b1a4a709808860.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '885be558db34e6a43b8f85cb3ff2bb4a',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/4205bb979377f624923765e1e2c7eb68.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a59ca0b43d1e791d4489011fff268ab',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/896afe85d71454dd1be299380ee642cf.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '257aa6f1ec69b558ae8fdcd56ca8a123',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/ebf8c4532759bcfb73ccc5cb62f73e40.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10b5965269ab24d827e164e634db1f85',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/abb9e78bc301a62a6a7dc0b488da0ca1.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ec6fda7d58cf4846a8e7e0c1fcaf5b6',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/73bc6d037ed66dee102cd8246d7e9a39.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11ea58e8d0fee65c22cd6fbd65d88d3c',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/7bceda03f96332fbdf7b444ac550b932.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8734d0ac0767b78a0db5b8561fae5c46',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/ae3a3a013c8190af9945483aa30bb70b.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09dacc0eb2a932c23643a9d0e54ba1c8',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/97df75f900f155f879f61d4b9764403a.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13915ec60c018efd97543dadd8ad8c3a',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/300348890086eca3f9d7ed7ed1a5ff6f.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc0673e870d14065aeaa6fb295985489',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/d33fd6b268f33bd4191daa85606d4e56.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5c4357c7ea14d30aabdbf1696a9129e',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/21a8ba5743efe21754c4470d2be303a1.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6725cb9df44ccd8636d80adfe63186e2',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/14a1ba11a6ae31e3623e6e3078afaa34.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dcce49007f5a9246088439475b736b5f',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/2d18f45c5b63ae7baa4f06e7dc2a858b.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57bdadc2c3db4458fefb696e4bb239e3',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/fa48c2dbf1a02b38436c5e7f28c41896.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3873c73ecab3f1e5ade2bd7e63cfcca',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/66a08c4f22b54b2d27cc94f25009af77.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8c31d7b415eba3337e51d157ec2996b',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/e6d75326a263c94a8bbd163afae2398a.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06566f97ec91e06b6475a78ae58642a5',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/a1794a33aeef8fe9bc6f249ec848f2a9.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d4a8b61e53a15dc0db27f0285202892',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/2285d1c8ee7b41888002e180c549d317.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd99ab702434aae9532a1a27162dc60b4',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/b59729f3ab224b1c3027c2d4cfe74904.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4054511cef9b567b76775db3cfd9902',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/d390114d44b7f24cc04977ff5e05d4c6.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bd9ea2b90290272c412bb44e670980c',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/04cfc6811058ec2f07d6d0609b6330fa.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d5cba81bddb534ae0a609dbae99d6ef',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/bd68a24ae6cc6f0f74455c0bb0fbd3e1.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7f8c5e138cda1b6c2782ca5e404b287',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/9bbddd3d437dffc750042b03a400e3fb.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcb680f61e3e53878925e2fe1b6c18e5',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/b7fd627827f4dbb8ba18594191a688b6.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a5c3b09db9f3931865c566226bb2c3b',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/0d1b1a8ee00ceb05a5b7dc046477d946.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe3cc37000eef7472fe277e2c3661942',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/333cee367db5994a4939148437fcc75f.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5c530008765549eb80e707f3a7562c6',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/52e7bd9a1949504bd0dfc3ae81746692.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41ed80621fcbfe85d5d0e129abafae72',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/8083b466895a90d4e601a68047d80b37.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c52e1b91eb44696350a746ce6836ad1',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/80cd35f005d21cbe49b355865cccf2be.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c45172dc062125ef6cca22267e5dc221',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/624184e178b57315867dcbdcdac0b1e7.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa77e20f1b2dc7529d766dba3c496e31',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/2d69d8c756534530a4795b3e30bcd839.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f380e8efce176fd688fb2c1b8c1ad0b0',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/a6d01823411b64e976a0949468cab00c.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '067b6040c45a6307093f47fa6725eca8',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/01c792caa08b9b409a0806c4e2fb1905.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef9c5c7b468fb465b4f0da7532129e0a',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/17d6026a0f952bcb67ae611f0ac06e8b.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6c7854803a9266f069a175c5b2e5c2f',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/ad53fa80b3246a5926dbe7aba4b565c9.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f0b823169b3418444cbbebbc29b9200',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/1ec75ff77123eed2b7dab2407850d5a4.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06b2ec8c1db3c9ff69a466efcdcd4078',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/bcf61eac4fa6338473dba356546df2d1.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6937ef97fbb9ec13f621986604cd42b',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/312d41ca9c8007b111383d0b252d0c05.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d1e032fd06eb62192444b2fde727c2b',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/d760c1f5731aa173909021ebf102b8ae.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96fc224676ac7cf207f7fbfb8ac81218',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/25c75c5fbd33ddad018cfde868fbbc3b.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4284ff0bdeae6126d0a73520738c92b9',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/4404f57738b9a4bbbda6c75430ca0953.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc9ee107c42064c6f6ca0c1a4d992233',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/d540b32f777f38576a975b5144e65977.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caa24265278b5d8c49421ddeb9b7f3f3',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/e78e45df3d1a0ff431f2bac162714e3e.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17cbf64d6a81511b3e76b7192447f7b1',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/6216b3ea9eda3db07b892a2b481c7b39.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd850dd3f589c6440550b7bb7541dbf6a',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/bad3dbc6d0838bbb7f90443978a30f13.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29c233d195338b10b5ea4cadd9375810',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/c7a0da0ec1a59dcb20a507aa02bbcd43.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddcb8fff8e0d5dcc75742fb8b582cc6a',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/66ad5061c22dfbf55f58c54bc8eb40a9.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8a5dacda9d264c3aa718b583c6e604d',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/78dde50c62513258d682ac927236c804.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91cf09d18ac99be2ebd5eed48c709ebb',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/91eabba0eea60679f8bc037783407ca8.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '971216d06cb55eafffd61128ea25eda6',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/f0815bb4b30b35a7260c25c7eba511fb.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '962993af710a408a41abd3f28c578c9a',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/a899e05e6e2249bad2e7035e31ca07c0.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '686e727bcaa211e9ed3f1117851b099b',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/4f5c6c06ffa6ddc3ba1f853cf999ae6d.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0334e2e3d5d64253147ccfc29d2d1d8',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/af08e792ac54622270245ba389fec30f.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94a10bc040f01dee340d1a812b2fa41c',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/2afcac4d10c901d2f5dddf6f399a579b.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e94fc1c4cb176621dc3840c5036ef831',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/ad9841c24fb97140310a0633ce782d47.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d60649924ec5b8babed89896db877ca',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/47c95f221418427aaeae26a2d9469e43.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff150dc9b91493bc9ca1b4f663f96b37',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/a3fd02c9589aff984628e9382910d336.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09cd65c8e2f6554d753ec3a4509af527',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/81a53b3134abd7a8a1df34ce3bd94811.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1f677ede85ee0bcadda4842d149335d',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/c1647d79668ffd0285590e4997bd1ff1.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a6535a29b28fffc7f3bc8ea1bc6238b',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/f502683ad6156cc09c8c175ffcd180ac.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71e87ba41219213d160a8908d4df3f09',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/cb37a8bc238e9b46c30b81156dc03e48.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b98df193fc3eb763ca7c7acccd8864e',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/d57fbd734f38d97f2e886480965891e4.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bec0daeceed2111ba14c5de4fffcf1e1',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/2c760647f99343e24f4eaddb339e74a3.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61e6612c5c1cbeeb338b85a9fefb45fe',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/18c44249f82503ccb7f93e6df98ebfea.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c8cdc55f46670c895847f92056cd162',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/b17ef71d8acae348741c80598242daf3.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '727ca8260500dfa6242b3bde3a69d67b',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/8f3b668476c0ccbb379aa08472860e38.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f97255e5519ce424cca744111b6706d0',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/2d62f641056f158f5cfd24bf2c2c574e.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16e117c76dec9d36e52af8e53fc48143',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/e96c5617ecc2c672defa099fe43230ee.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6178134dcba188c264c1971489795b0b',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/f49b060316f3a6e596bfb5a606628bb4.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87be1fd242d18e4e24fa64abf43e408a',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/0d708e3799a43a5606d8866f9ae1f8f3.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bfcf59f2813ead2e27ad8eb1cd0475a',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/78814eeae772acd22c9f6b5c33c75ef3.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '801f5ea3f6fc4ea6b06110dcaeeb345a',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/3a56bd31be79d7f8b45f9c067886bd66.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff33022c7936864c5cebcbde3b66f8b1',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/142ec9df8e07d19959207fb45b99fcfe.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '367bd59e4847730af0caeea65fac3f1f',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/6456fad55277abe93cb3de01c828182f.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5c235fe3d011d900e91a8b29a6b21b4',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/a0b68e15b67b07d9e47ee03fe068df54.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '078d7d74135de90d9f544397afb5421b',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/e55f5893b2db3f3082fcacaa9f3c2079.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86a48275b4ccf5a0ae927cfcae5169c8',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/d66a767a2659240f832ff247d54f6a67.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3861114b0c2e21cf21421e12344eabf9',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/a799dd721d7e8cb6039a359a45d97c63.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3068f4716a618197829439a974dcf86d',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/f08d80658734cd49ed598bc1eea2af5e.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '612ad8310dd6f9dc540441a4dc7bbd55',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/88fbf0c6df56e5080e85b40a2fe4d4f9.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '637fde1598e82ee2228853d735831501',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/d8d5ccab9e08eef5a4e07a173c609cf8.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '897d2f31b3c31fe8866a24d3a98cf7a1',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/a37c6c799c2f894bc060da8366bb96d3.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e24edfad86098e9490aa61d5f49c6703',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/ac24ae752a1e2ece1b0ab0b00c5cb16b.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7df97ebdf085ef42106ef6bfdb1f59e',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/3d268af857b614bfc93d31d0985ce128.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2125930a6b7e219f5af0d9b0b853e48',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/651440acd206c531399fccb98bd4d5c2.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aebb7c59295a002698167aa46e7f8e9d',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/7db4a692290b22410058418c1fda21dc.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c71e0ebcd2ca40b39b1570c5acd4428e',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/fe4c87b2895bc9d9c31de922739ff169.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '018bcdbf15f7a6a13e1b17bc1d40ea7e',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/c95ddd3de3e1d18d02eceb47f3077749.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c355ce735b90400dc94d575398da123f',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/843b5640cd95d0b509aa66b88c1cfe73.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91d21f3bf5b21f448fc3138f3c03022b',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/b3baaf9950e9be943adcabe336888651.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce5f2a4ec73dee3e23c4077756d687a7',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/473b5013b4f451ccd019b3b022325333.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f9a67f64c4f51722b7ddcebf40907f1',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/9521d66deb45a2acd7da2b1fd94fa176.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '209047f8555a64131106067893782b5b',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/8b4f866f8532ec9f94d898f5e6db6226.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b19d60a30dcb4257fa7aef7711c9b34d',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/94916cccc8b884f4dd6a4a2288830e73.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b5f289582d4eaae7f9cda62e560d7f3',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/2a80414802dfe9b8c2ee96f3c75e1b6f.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6831bc48a9e80144778b9769fa44d15',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/051ee3abddff8fbd90a7acf05bc4d73f.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '285ec54394e8fca4b9fbe694f2ced769',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/7579a2cafa4c0aa6d9e9e03426025f84.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fc141242a28cfa852c393ad553bd4fd',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/0591dc85cf4ed8b7a3119d0573f9a42c.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '555f3bda34d0dbdf7318bcd6d705767a',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/1e611c57787ffeac8ff2c0c7ae8ac386.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '297afefee0c63373d695bc6df8fe1388',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/87652052fe29ffa3e85eb18fff80bf7a.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef75adcbc0affd97b0c3008c0b113ae8',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/3f0e3e06518262bd18fd090d3526d5d2.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76f1ab78ccdd2c61cd809b75e9a27d61',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/4fb558790349b1fd28442b7458b2931f.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45691d4d167c6936393b8ae3c1332bc9',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/da5ede8b1a3f17e37985ccdaf80baf87.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0f5e562625de37d9a0a87495c37b4ba',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/871e1ef26a66334c7abd2a586e357076.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'babfcb9e028f37b6f4a3ae1690e1dacb',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/3b05067a9305a172a64c31b0e3f80ad9.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad15916d4ebed824f8ddb786461c3066',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/8365570f04823ba9c6f65eef482c145e.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c85416033fe750f277d8581d0ed5c3b7',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/a20cd7661371ac653c32bf97cb8177db.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af4f180c2cf8f3bc404457f3420e58c0',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/8298683bca897ae573b4d1311aae63a1.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '805d080eb108c306ebcd00c22167c23a',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/5f4b3b9c91d22065e8340264a2cf81ad.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '819446492dd5198f5b7820283f17ea85',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/0dcc330c2010f105a47f367ac1a09850.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd44f3fe1dc90ed6da10c711d6c8694c',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/7ad9a05332b8630a25560f5d7104720f.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17457d4c02c84432af52e9b17707c140',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/6a35c34bcddcfe0a087ce079dc40dd14.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5b22371c51d3f260f22949422cbb528',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/97466025fa84bffca96cd9e4c4a10881.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd808f43b2a9db8d7005f0b14820e6983',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/7550f130a0c2cc92fc284c2bebf4647f.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '240a5b97c4053c00b13950428dde4ea4',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/2d9130e7a7600e43b269cae64ba15e3b.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f6e6d927df9c4459d45afc5e13bc099',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/d3d7c635fbb37e51f7f3f25f19809ce9.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1af0daaabe90f72e489f02a7200a932a',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/93f4fd675f53382860181dc8ddc25648.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c34c6c290d0ce3c96bc08b3bddfdb531',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/d6cd35954771eaac73e18291f9d3a41a.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0623027f11bc49e88ffc6ac2a793bf2f',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/1052184fbaa39ddd67ce4b5049d1ea17.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f058cfd4fd55876d6c8a39fff609db05',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/1ed6d41c096eb2e34a762fc784a834b2.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '755f698351ec681904a081973c8cc03f',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/f243ac0aceb0e9dd50280aa7126f4120.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82286851774b48b8c02e6f253ec6979b',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/4711c771fd4b21a3bc3727e31347a9ee.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e54a7684d16d0b0876839866e5f1295',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/26f3ffb8048c5b394615b67bf6d6cbef.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d10c0634ad82bf4abb0ad228652a479',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/f8974c16ad75a000395c5aacc0f95c28.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7cd1f70d39403b514c65b125dd85359',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/20029a8939cd3da9d3962d6ac51503c6.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd40da496e51b43d0e9cf6641f11c1208',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/e2978192f03f8b98852851d27f0c0868.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc3dc6013b05cbfa9adfa4a7806ddd72',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/4b8ddd7edb57a2e7b88e778a2d9f0808.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6db1705a845c6acc97ce12e3f59ada0e',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/6c056ff7bb98b2abb7c91889586f5b63.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7485d15e1ee0f57f08100e5f7f4faca6',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/af29283cb48ae0fd8b96d47a2768c761.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd4389f0751641faa2b9cdc2b192183f',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/5fa1fa746a54703120c16d5828dbb3de.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fc25a74f50e7e11f395c8986ef231e8',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/f03154d1957fbc6d58a16b3cd6256238.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a84f00c8f42249c930de74f4802abb9',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/62caf3ee881d71fc8c665b79a3bca2b9.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cf04df3e5d7caec6e0a8c8e60ff20b9',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/88599c58024d913019324ccea6f185af.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40a50c99f8c44c8d25759ecbe3c5f202',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/4edcd59df0669c3902a654996863ee63.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aadc3a9e5eee36728254570a8ef3c369',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/1ae0e7d8f7baab0347c33a2bd10fe9f6.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d0854b5454c197c8c5642e44d7b3ef1',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/d5d353d7477e6a1e825ddaee79bde062.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ddf26c160daebc8b429d8b1a08e5401',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/3aa26eab877873149ce718b1d89bf9ab.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e687cf47ea1a5424c9d1c9e3e9735a48',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/d2c542a18e131c914bbd064fb946ce52.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c006765f3f00df0640d0bce8fc424369',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/74c9b7eac0141fcbc744b7b314af390a.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd506b9d846c4660d9b0c27d64bbadd1d',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/ab208480282565f868f44b53ecd1f23a.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57836c5c883be4994f336b72d9dec70a',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/96fe610cc8bf04ebda64f6aeb9a650c8.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f21ad6bb48a348b4aa4440a4e03430a',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/f24357c2789ebe2c5c9b2ac4c3b5f8ad.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab537d174ea75e379ccfb0aebf9911fe',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/daa6f80d4af2ab9b798707cacf8c79bd.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8547245d2c999d7f678310e4925d676',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/84e5260b342af67151c1307aa7d8d403.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65c85b55b2c1ef714a2c3cb08afa186a',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/3530a0eb67b84e0d5583b042bf65ed2d.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '986428d6891e90c2fbb425f61dd21dc1',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/c9fb43bd48ca2738fe0c832c880ed57d.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '302bc63e3e9bb794be1a3fbdffb6a990',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/2a524ac852891abf15a817c9d4975dbf.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81912a77e713939b3a2d34868d9c58e2',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/27494239eb4f1588fc32010995b695bb.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '234235c34ab0013b1fa4bbc86e2e4078',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/c985b8f2b6601738a6b7d9f28d464cc3.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c7a32a9addf60923cb52bf64d887caf',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/967df0b8e21fc8cc0f040db3a1064981.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff7a565b8b24597ff4c5c3e501c2c54a',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/9863036e77647b6234442b11fa662eac.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34c96e71645e75df27827fd8fdc05f15',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/1aacdef3269148f2dd96781fd49462c2.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '779d71660d3859250d209dc218defbd1',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/891e65af46cb54160e68337aa1b8d6e7.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25f64dc38c21a8b9fab16e3214f23723',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/8832c256da44c093a04a98b0486c17f8.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e24f48e0dcbe5af7eeca88dbb308b60b',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/e813f4717b2112b9e46a28a72badad91.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae439b4316ca7c695be4f5d140a4a382',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/bfa68d7b0991f275c425610c7f9b0018.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1b3cab54a321b8c963d85b4b418d33e',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/a286da2ed825e5cbe9ef2af586d0986c.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3277331a958883a43bb0c0f957562230',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/6dbef4b1bb44fcbd5b03a5d9a71d74fb.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f68f18cb5c38d6d14cbfb3dda4889876',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/8f4767ac8fde99004a26deff5e3505fc.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8e7cb2b3c3d43799e07675b9ae76594',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/75f9c110329cd8cf4d25d47b69140003.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a4966419b982acf267d7ae5f7182af9',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/0e608e5eb69ce30288a2a9df02e1738a.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28d2ce9e8cd6b22404cd508c86d7ca32',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/8cb37d57a9c61bffb8bfcf0cbd324912.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de5fb42397112871110380b4be0023cd',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/8d3950e8807920ccdbd243697ac1e2b2.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66f5fd9235735d5f625ffa50122ca200',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/ad871b1e9b3ec1427bbcb091c7f333b6.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1882bf09fbd93322bda038c661324434',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/b0b5b425ce918a23ddc334cc68554908.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0389ba1f66ff3c1b7483bf5aab59fc7f',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/6e1b0e32f46c80c3342afa78d5a6ec30.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b685d50755dd6873b8344843e6c99e38',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/22f9d3750a56a9edcfb06c2d3c52727d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd97272a04160b99b6644b01d111422a2',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/862e38d18bcdebea3e9ed2f114b11565.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96a2c55af4aedbf6fb4199eee35668a9',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/b69be3e7363d51d4251eb34924de2a86.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa3015ee9465e12bee53ef7a4b53c65d',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/ca7f8a9ec4978bf96d8fcb87c1268f30.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4c5ceec779b282fd090b5af62da188e',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/c8e0291c969807bfcd8d6dd5c0ac985f.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b9ca13c2ea9c24bf579a989a9b6370d',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/1d306ce19e354497447a3e9a619dc1b8.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '820ee3e5bf9e7c36348e228d2ffc26f0',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/b43525f5b8f15b973eaed1fe21220662.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '565ea9dafe04a6fd0097ba4ea2e8aebc',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/bc80effe93a0af32a0ab1f6bc9d1fdc7.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfd715ccc06ce6a6b9365c7b1a3fb049',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/69f1b7da8f03fa9491bbce7d1861454a.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb31579d9914c4fcee683bc9c3abb01b',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/a406ddb38aa9de181659faae6b1164ce.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b8c929902cab4e6f4771779e6107e59',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/2a010d73cbc6c6722b8e3486aef8cdce.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ba65d05dd7953b2ae3390ce9ca0b83c',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/c29049fe5a26eec66e454a7635545479.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6946611d1e84e471bae2f54fa07aeff8',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/b156afdf741053ed80a3e98e809ca343.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b22e0f672004434d28e9ed5de3a3454e',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/d2330206c295546b6898595461f094de.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a561047e2b2547eacf8f01c4f41132b',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/067bba3d0c920562e53dc62581d25407.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19a9be65dfe44f1ccbe75bca4b656fec',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/fe4a1a7c40f869028e3c800a53000ddb.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2886f857110dbbfe379b6e8f26af286a',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/384cbbea2008881aa0b602985796b43e.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acc7d48a14b348f3cbe82458d35c37ac',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/e7a4aeed01592260bef7a393d844db99.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f42227dbb4e8c338820a962196954d1',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/95c787f8adeb2e1c291e5d5785b175c8.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fc503ee198ccc2b037792854fd170f8',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/10fed32957d28b49cb741f2a5e01acb0.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a76c5923a19feeebc3b74c9a30d834d',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/02da1989a88c9eb04ecde83e89a110c3.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51ba5f0fd4bea0de3f858e1b02b2f66e',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/f9c513e9b41e243d030092d74d1b7cba.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d6b7d8a801b98b574fdc0ffea68f5a1',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/be12cac1e6ad493db120900822dbc3aa.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4bfe29af1384ccd83ca4c262a6cf9b8',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/1d4b5acd4fa4defbcc546da39edf9741.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9de93d632e41554e935c4e45ac0a3870',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/eb9b9c2e131f33f2ca3f1a7ad1c829fa.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31602cc8fd47c172c3992e336db5301b',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/50f55c909e6934eac69e174a34dc05a5.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '280e94627982ceea9ee0717f7955477f',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/4f9386508128efd4b5baa24b363c432b.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf6877b08dd23919ef9ce213ca210077',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/b640e83de2d3db638bf9537fccef6fc4.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e79c54763bb9a89be5ac2770e78b526a',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/68d9293fdf99481b710ef291704348e7.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '858735dc0ceeffb3fae3627497d4a034',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/ca55554db8a5d3c06b1834e897ebafde.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f01d3cc16defff280e5d666f914dc547',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/08af10de7b72ea1d14853809d62b6198.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68a04a7e4dd274dc1a449ff51f3994a7',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/d5774f73508623bafb1f427f265b3b7f.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cfbbf0472e53f5fe043f8e6cfc42807',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/c32a63a953f5fb34cbf931faf1d1f5a4.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6583b62307957e115e80af018f78eb1',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/9503802fd5df7b1e74295d3d65286c79.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5eb11d33adafcff9bad8d9e951cceea',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/657c9ea6f66e80ab893ef656a01c3eb3.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a4184ef8acbe80e030a5a96a4dd9109',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/76d3abc96f2338e0032776457b967526.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c15cb7321a60c2b2c9f6ba2b499fa42',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/1f2a3ce046344e782ec40f93d1e6f73f.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3235781e734761f41b16c7ab3ddf691c',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/9f6c98d4f14b12dbaa8f8b205a7d3f7c.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '954e7e0d7ca55a73fa2cb7c90833b33c',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/6f34c8f1d1382915f79815c50b1b6e48.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4da5c306449bacf370265d0d284b347',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/ebbdf14d5e8431e2a63afcd4162fc646.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac94e55d99af60d1b5c0a976368d50d7',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/89d2dcf1d3fb6b5ce1f74c37b5e7e0a1.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '130b1bad91e477afa7be9578eb994808',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/2497d43f0e01a9c4294376d65aaf266b.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a26045887ef23f745b36cd22121ba861',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/165df8851ef911591f00e0a4afccec5d.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c2cd9932146da107eeab2297129d938',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/9addf67bf79cf4ded0cacea44bef5967.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee8cacdeb8c46fb2cbf2b7340852feca',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/88e0d951cf377f36fe3be03ae1ab5ab1.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a1411318ed7e9f0718aa81df52697fb',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/37af97bbf90b8ed76fe05e0c6bfa2a01.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67b7862acec14c953adccf79d0513a8a',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/9ebfc42a95e6c283da899d6f6ddc7cb8.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa4e4f4d1a17bd2f0212b0f1b225aceb',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/2ebbf542f61821f5d8586aba9bc63d78.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a981a263fd0605a351c80fa259416c0c',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/2491551c10120fb44faeac6418c5599c.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee0526925056c6b959e0f8b1597f1889',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/2c33c94f7063cb981b243235bd273fff.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd74dd87e8dcd3debe98564e5d949ff1',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/c5ba19a7c957e1e2b49aa91a6879f311.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48217903e1680905498029fb028eecfb',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/35a8a1c484bb0a32e4599873258dd6d9.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6187e6bd7dce31a07b1b674436b7ce8',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/3a7174838d5561648bd65fb7179af5d9.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a64f4ecb030921b20147a3970671bb7e',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/3cd6d3e44a93e616a7e7445b60cee283.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '759a415fd6fc63a1054bd660952d9542',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/8705e76e40f2218e013d9c755a4fb9bf.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '685f0ef81313cbba987aef3ed78f32ff',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/b6fd74c4c052bedb32d4bdd209dcf532.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d5a7fd7537fce053b9f6379613551de',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/e098d16b0aa14864f3396ab1daf63548.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3f5309a85daab92a102cb5b9fb12982',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/196b5fe931835c45080422c3bd8e3f0e.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27251d343a704e1f27a3038ec07ec754',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/166cd4a5ece64cfba4817fc1ae27587a.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ad9ebfbd252d3021e4fce677ae9c628',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/0f9369cbbbc85f030613eafa399b2d1b.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '76c681d17ae116a0b0a1a36845a8cc7a',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/83c5c1822f0474d64621819b0f6e4888.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3c0bcee1de97092508336779b78b7c67',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/1092c57c053a2f9bdfc97faec52f6335.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '0ad44d0172dc8b81f8391f58f1f697c1',
      'native_key' => 1,
      'filename' => 'modUserGroup/61eb2909c7d8c0e02d1a3983b5ef84a9.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '0f3a76f1a780e1eb6a6c5236b7f996ad',
      'native_key' => 1,
      'filename' => 'modDashboard/e0b478d4a7956ca314997e5d737ec37a.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '715dfd8eb2a22c826b0b72624cee0c82',
      'native_key' => 1,
      'filename' => 'modMediaSource/0fb3967e070daab9c662f7debbfdd9db.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '2b25289961e1fe15108cdf7a71de4cbe',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d93098a3acbc99e042a1bd85403b55bd.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e57a87e61f8ef2c53281290a1a5da487',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e1d9e4c2c3480fd5a53e85513e6bfe1e.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '4aaed42cfa13ada28701a392627809c8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/f7f9f701250b42153a86d0e9dee0824b.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8d92dfbf66d457bcd42d2d51387d4f50',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/45597cf7146ae1fc3a0998ccba94d7a4.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e666d23b7ba10b561a88ccc6b14104dc',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2a4a8548b13c7e81f25e429fea09b887.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '3755d92f2ad9773f1069ed473a47000c',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/ce12d39e83c80fb0b41cc35d627e4909.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'dc4b655cc58541db3175cd962fd7de91',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/4afc1f79550c1b8be64ac0650237e3ee.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ca9277ec17e8df6394a22508015d0978',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/9051434f46cf5ded667d1254d5676367.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f0aaa70be9a813aca2b0fbdbe5dae3f8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/10db0846289720734911c9b5f05482dd.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3316783041e52bb19ab73bb97847884c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/aeba90ab05ad36a87397353b1c21b25e.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c5a79a3df08d7c2ce75cfbecf7a25ef4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/03352dd52bd0d3979e38ea918439714b.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e120cafa873bdb09ac1d081b8300cbef',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/aaf891300323f3e547d9ec23920d5f6c.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '59fb23ec66d0d4ca4dce7259947784ac',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/de6073082bc41d9c21e9bd64f6a9f410.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '400634c3a059b54a2a4108d0749de30b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/53daf9b63373668e604201fc55d30fd5.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'be901763ad92b75c267e8c787652b9b5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c0aaf915390dd5a39b45bfe0479b6f17.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8a70d5de9bf3c6ae4ac33368f606c35d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/311507e17c6afae08e544f3e9b24e03e.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '42a9459621d5a5a10f628bdaa89ef69e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/992136978b44acb8dce32e982b168279.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '363baa500501b44a7efa510b995447fb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/804e9ae18eb3fff1321ece0e40070afc.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ffce702dc365b7cc2fe8573be88d24ea',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/34d77781cdae3d6cee7e0f86a7e3a90e.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c4405b150e582b4cf05915b46b08a555',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/6e4fa25de259c277d8d5ce07a87df3f9.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bd3740faefb241b04da30cb4c73740d8',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/eb0cb7b588147202fb21098b8dd9b043.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9e1f83f01b70ee71a9c434e6f924dbae',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/d0af2ef4e74acb934712bc66b6ef72b6.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ed1e1922b167d26ab80cc8d98c5c838a',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/e633a5a90ae6986e880074e67ac7ee1c.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0889a2cc8b81a50c0f3ba56ab6c3e9a4',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/927498ac911dcccca91d312e23683826.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '66438e68bafa5c09bdd60f3503716f87',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/2de03072d222dd6f74d839102db7d960.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '870d3f0b67d8a3f832f3ea4615c976cc',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/f92e0ea9f759952993547fcd99c610d2.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '169be65acee6e756e0ceecf27f04d6dc',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/a8edad30bf67b11cc3d0abeecf60d813.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2a501f4146d719e86f9f7c630917c693',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/60f2a8d1d2d388021ea70cfc10281a23.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7996c8dce4887c86407601d9dd2047ad',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/92157a26c591c794dc62e6ed287fedc8.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '51b10b43ba6e084b8fe28efd3fdb9823',
      'native_key' => 'web',
      'filename' => 'modContext/f0a70176dc683a7939121f02536cc6d2.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '88590985a6b0defb0051dd41165991d7',
      'native_key' => 'mgr',
      'filename' => 'modContext/a5f02af90eec8b613bd7efefbd573038.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '65331a9f1f3d520d6b5d16e56bd912b8',
      'native_key' => '65331a9f1f3d520d6b5d16e56bd912b8',
      'filename' => 'xPDOFileVehicle/c7f15ed432d3ad5e9c782f192248f880.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '45ee5c4414d57f821c76631617d21f6c',
      'native_key' => '45ee5c4414d57f821c76631617d21f6c',
      'filename' => 'xPDOFileVehicle/e80c71e366b0c6f7f7702b7f47910911.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'efa15d34f7b1c9a78d7f9f003ab708f9',
      'native_key' => 'efa15d34f7b1c9a78d7f9f003ab708f9',
      'filename' => 'xPDOFileVehicle/c501a6fcd3d983c7108950a3428db356.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '442e7d3b40e8e0f28f81e8b8febcc23c',
      'native_key' => '442e7d3b40e8e0f28f81e8b8febcc23c',
      'filename' => 'xPDOFileVehicle/284e72252a89a97a1f1ce54170bfb18f.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8757391e05f212fee648502f6cafe80a',
      'native_key' => '8757391e05f212fee648502f6cafe80a',
      'filename' => 'xPDOFileVehicle/4e71a3b1e5d07d5331e64198a4d031dd.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '72c59fde94e03812c93f7699394bf3d3',
      'native_key' => '72c59fde94e03812c93f7699394bf3d3',
      'filename' => 'xPDOFileVehicle/eea1733a4b6d338ff90d88915603baad.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '16973408322410ddbcbe3309d57e814d',
      'native_key' => '16973408322410ddbcbe3309d57e814d',
      'filename' => 'xPDOFileVehicle/ca9e4de46195226a3032199baf5c9a21.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '95357d02db5c3e4ec147467a33f0df0a',
      'native_key' => '95357d02db5c3e4ec147467a33f0df0a',
      'filename' => 'xPDOFileVehicle/d55084ac95e3cf4d7e9e52efbab22ced.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '631134c4aecdf178e4c7cea03dc2653c',
      'native_key' => '631134c4aecdf178e4c7cea03dc2653c',
      'filename' => 'xPDOFileVehicle/bed624aeb5d2a8a199101820d0290af1.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '77759071ad133a1a869a33fdba0e946c',
      'native_key' => '77759071ad133a1a869a33fdba0e946c',
      'filename' => 'xPDOFileVehicle/3df9aeea11d5212138c3567bcb68bde1.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a13dfcfc5ae012967865ae3e6a6dd211',
      'native_key' => 'a13dfcfc5ae012967865ae3e6a6dd211',
      'filename' => 'xPDOFileVehicle/b39676001ca4bb507f8b849469494ff0.vehicle',
    ),
  ),
);