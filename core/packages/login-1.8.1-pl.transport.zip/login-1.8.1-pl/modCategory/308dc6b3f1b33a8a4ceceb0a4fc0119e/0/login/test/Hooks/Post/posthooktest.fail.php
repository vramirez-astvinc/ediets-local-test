<?php
$hook->addError('fullname','This is a failed hook.');
return false;