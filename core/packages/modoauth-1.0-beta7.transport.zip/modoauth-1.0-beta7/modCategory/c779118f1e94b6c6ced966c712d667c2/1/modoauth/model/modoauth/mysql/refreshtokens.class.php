<?php
require_once (dirname(dirname(__FILE__)) . '/refreshtokens.class.php');
class RefreshTokens_mysql extends RefreshTokens {}