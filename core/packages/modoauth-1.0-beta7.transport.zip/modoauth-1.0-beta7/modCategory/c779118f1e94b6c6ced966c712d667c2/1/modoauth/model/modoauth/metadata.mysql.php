<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'Clients',
    1 => 'Tokens',
    2 => 'AuthCodes',
    3 => 'RefreshTokens',
  ),
);