<?php
class AuthCodes extends xPDOSimpleObject {}