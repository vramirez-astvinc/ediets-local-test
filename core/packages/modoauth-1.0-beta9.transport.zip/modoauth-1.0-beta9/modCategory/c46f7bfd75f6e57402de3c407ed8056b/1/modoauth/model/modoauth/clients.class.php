<?php
class Clients extends xPDOSimpleObject {}