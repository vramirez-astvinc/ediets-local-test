<?php
class Tokens extends xPDOSimpleObject {}